<? php
$name = $_POST['name'];
$email_id = $_POST['email'];
$city = $_POST['city'];
$message = $_POST['message'];


$email_from ='info@yourwebsite.com';
$email_subject = 'New visitor';
$email_body = "User Name: $name.\n".
               "User Name: $visitor_email.\n".
               "User Name: $city.\n".
               "User Name: $message.\n";


$to = 'priyanka96325@gmail.com';


$headers ="From: $email_from \r\n";    //  \r is carriage return  

$headers .="Reply-To: $visiot_email \r\n";


mail($to, $email_subject,$email_body,$headers);
header("Location: contact.html");





?>
